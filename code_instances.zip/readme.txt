run code: ./code/svrpc ./instances/set_III/data20a_3.txt results/set_III/data20a_3_0.txt 60000 300000 0
The binary code can run under gcc --version 9.4.0
